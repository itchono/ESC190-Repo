#include <stdio.h>
int main(){
 long long int x = 1234567890000;
 printf("%lld\n", x);
}

